Kurd Tools - first website version

To publish with GitHub Pages:
1. Create a new public repository named kurd-tools.
2. Upload index.html to the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment choose Deploy from a branch.
5. Select main branch and /(root), then Save.
6. Wait a minute or two. GitHub will show your free website address.

The current version is a static website. Some tools work directly in the browser; other planned tools will be added in later updates. QR generation uses an external QR service.
